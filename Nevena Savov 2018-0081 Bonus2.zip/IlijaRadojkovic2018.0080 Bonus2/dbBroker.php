<?php
$host = "localhost";
$db = "kolokvijumi";
$user = "root";
$password = "";

$conn = new mysqli($host,$user,$password,$db,3306);


if ($conn->connect_errno){
    exit("Nauspesna konekcija: greska> ".$conn->connect_error.", err kod>".$conn->connect_errno);
}

?>